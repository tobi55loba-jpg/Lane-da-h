// Lane Dash — experiment game (Phaser 3)
const W = 360, H = 640, LANES = 3, LANE_W = W / LANES;
const laneX = l => LANE_W * l + LANE_W / 2;
let best = 0; try { best = +localStorage.getItem('laneDashBest') || 0; } catch (e) {}

class Menu extends Phaser.Scene {
  constructor() { super('Menu'); }
  create() {
    this.cameras.main.setBackgroundColor('#141428');
    this.add.text(W / 2, 200, 'LANE DASH', { fontFamily: 'Arial Black, Arial', fontSize: '44px', color: '#ffd23f' }).setOrigin(0.5);
    this.add.text(W / 2, 255, 'Dodge the blocks. Grab the coins.', { fontFamily: 'Arial', fontSize: '16px', color: '#ccccff' }).setOrigin(0.5);
    this.add.text(W / 2, 300, 'Best: ' + best, { fontFamily: 'Arial', fontSize: '20px', color: '#ffffff' }).setOrigin(0.5);
    const btn = this.add.rectangle(W / 2, 400, 200, 64, 0x3ddc97).setInteractive({ useHandCursor: true });
    this.add.text(W / 2, 400, 'PLAY', { fontFamily: 'Arial Black, Arial', fontSize: '28px', color: '#141428' }).setOrigin(0.5);
    this.add.text(W / 2, 470, 'Tap left or right side to move', { fontFamily: 'Arial', fontSize: '14px', color: '#8888aa' }).setOrigin(0.5);
    btn.on('pointerdown', () => this.scene.start('Game', { score: 0, revived: false }));
  }
}

class Game extends Phaser.Scene {
  constructor() { super('Game'); }
  init(d) { this.score = d.score || 0; this.revived = d.revived; }
  create() {
    this.cameras.main.setBackgroundColor('#1b1b3a');
    for (let i = 1; i < LANES; i++) this.add.rectangle(LANE_W * i, H / 2, 2, H, 0x33335a);
    this.lane = 1;
    this.player = this.add.rectangle(laneX(1), H - 140, 50, 50, 0x3ddc97);
    this.physics.add.existing(this.player);
    this.blocks = this.physics.add.group();
    this.coins = this.physics.add.group();
    this.speed = 260 + Math.min(this.score * 2, 340);
    this.scoreText = this.add.text(16, 14, 'Score: ' + this.score, { fontFamily: 'Arial Black, Arial', fontSize: '22px', color: '#fff' }).setDepth(5);
    this.spawnEvt = this.time.addEvent({ delay: 700, loop: true, callback: () => this.spawn() });
    this.time.addEvent({ delay: 250, loop: true, callback: () => { this.score++; this.scoreText.setText('Score: ' + this.score); this.speed = Math.min(this.speed + 1.5, 650); } });
    this.input.on('pointerdown', p => this.move(p.x < W / 2 ? -1 : 1));
    this.input.keyboard?.on('keydown-LEFT', () => this.move(-1));
    this.input.keyboard?.on('keydown-RIGHT', () => this.move(1));
    this.physics.add.overlap(this.player, this.blocks, () => this.crash());
    this.physics.add.overlap(this.player, this.coins, (pl, c) => { c.destroy(); this.score += 10; this.scoreText.setText('Score: ' + this.score); this.flash('+10'); });
    this.dead = false;
    if (this.revived) this.flash('Revived!');
  }
  move(dir) {
    if (this.dead) return;
    this.lane = Phaser.Math.Clamp(this.lane + dir, 0, LANES - 1);
    this.tweens.add({ targets: this.player, x: laneX(this.lane), duration: 90 });
  }
  spawn() {
    const free = Phaser.Math.Between(0, LANES - 1);
    for (let l = 0; l < LANES; l++) {
      if (l === free) {
        if (Math.random() < 0.4) { const c = this.add.circle(laneX(l), -30, 14, 0xffd23f); this.coins.add(c); c.body.setVelocityY(this.speed); }
      } else if (Math.random() < 0.55) {
        const b = this.add.rectangle(laneX(l), -30, LANE_W - 30, 40, 0xff5d73); this.blocks.add(b); b.body.setVelocityY(this.speed);
      }
    }
    [...this.blocks.getChildren(), ...this.coins.getChildren()].forEach(o => { if (o.y > H + 50) o.destroy(); });
  }
  flash(t) {
    const tx = this.add.text(this.player.x, this.player.y - 50, t, { fontFamily: 'Arial Black, Arial', fontSize: '20px', color: '#ffd23f' }).setOrigin(0.5);
    this.tweens.add({ targets: tx, y: tx.y - 40, alpha: 0, duration: 600, onComplete: () => tx.destroy() });
  }
  crash() {
    if (this.dead) return; this.dead = true;
    this.physics.pause(); this.time.removeAllEvents(); this.cameras.main.shake(200, 0.01);
    if (this.score > best) { best = this.score; try { localStorage.setItem('laneDashBest', best); } catch (e) {} }
    this.time.delayedCall(400, () => this.scene.start('Over', { score: this.score, revived: this.revived }));
  }
}

class Over extends Phaser.Scene {
  constructor() { super('Over'); }
  init(d) { this.score = d.score; this.revived = d.revived; }
  create() {
    this.cameras.main.setBackgroundColor('#141428');
    this.add.text(W / 2, 160, 'GAME OVER', { fontFamily: 'Arial Black, Arial', fontSize: '40px', color: '#ff5d73' }).setOrigin(0.5);
    this.add.text(W / 2, 220, 'Score: ' + this.score, { fontFamily: 'Arial', fontSize: '24px', color: '#fff' }).setOrigin(0.5);
    this.add.text(W / 2, 255, 'Best: ' + best, { fontFamily: 'Arial', fontSize: '18px', color: '#ccccff' }).setOrigin(0.5);
    if (!this.revived) {
      this.button(340, 0xffd23f, '▶ Watch ad to continue', () => this.fakeAd());
      this.add.text(W / 2, 382, '(rewarded ad spot)', { fontFamily: 'Arial', fontSize: '12px', color: '#8888aa' }).setOrigin(0.5);
    }
    this.button(440, 0x3ddc97, 'Play again', () => { this.fakeInterstitial(); });
    this.button(520, 0x555588, 'Menu', () => this.scene.start('Menu'));
  }
  button(y, color, label, fn) {
    const r = this.add.rectangle(W / 2, y, 260, 56, color).setInteractive({ useHandCursor: true });
    this.add.text(W / 2, y, label, { fontFamily: 'Arial Black, Arial', fontSize: '18px', color: '#141428' }).setOrigin(0.5);
    r.on('pointerdown', fn);
  }
  overlay(title, secs, done) {
    const bg = this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.92).setInteractive().setDepth(10);
    const t = this.add.text(W / 2, H / 2 - 30, title, { fontFamily: 'Arial Black, Arial', fontSize: '22px', color: '#fff', align: 'center' }).setOrigin(0.5).setDepth(11);
    const c = this.add.text(W / 2, H / 2 + 20, secs + '', { fontFamily: 'Arial', fontSize: '36px', color: '#ffd23f' }).setOrigin(0.5).setDepth(11);
    let n = secs;
    this.time.addEvent({ delay: 1000, repeat: secs - 1, callback: () => { n--; c.setText(n + ''); if (n === 0) done(); } });
  }
  fakeAd() { this.overlay('TEST AD\n(a real rewarded ad plays here)', 3, () => this.scene.start('Game', { score: this.score, revived: true })); }
  fakeInterstitial() {
    // Real games show an interstitial every few rounds, not every time
    window.rounds = (window.rounds || 0) + 1;
    if (window.rounds % 3 === 0) this.overlay('TEST AD\n(interstitial every 3 rounds)', 2, () => this.scene.start('Game', { score: 0, revived: false }));
    else this.scene.start('Game', { score: 0, revived: false });
  }
}

new Phaser.Game({
  type: Phaser.AUTO, parent: 'game', width: W, height: H,
  physics: { default: 'arcade' },
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  scene: [Menu, Game, Over]
});
